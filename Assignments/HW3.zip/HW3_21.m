clear all;   % Clear the memory
%* Set initial position and velocity of pendulum
theta0 = input('Enter initial angle (in degrees): ');
theta = theta0*pi/180;   % Convert angle to radians
omega = 0;               % Set the initial velocity
%* Set the physical constants and other variables
g_over_L=1;                % The constant g
time = 0;                % Initial time
A0=input('Input the amplitude of the driving force as a multiple of g: ');
Td=input('Input the period of the driving force (s): ');
tau=input('Input the time step (s): ');
%* Take one backward step to start Verlet
accel = -(g_over_L)*sin(theta);    % Gravitational acceleration
theta_old = theta - omega*tau + 0.5*tau^2*accel;    
%* Loop over desired number of steps with given time step
%    and numerical method
maxtime=100*Td/tau;
for istep=1:maxtime  
  %* Record angle and time for plotting
  t_plot(istep) = time;            
  th_plot(istep) = theta*180/pi;   % Convert angle to degrees
  time = time + tau;
  ad=A0*sin(2*pi*time/Td);  %acceleration from the driving force
  accel = -((g_over_L+ad))*sin(theta);    % total acceleration
  theta_new = 2*theta - theta_old + tau^2*accel;
  theta_old = theta;			   % Verlet method
  theta = theta_new;  
end
plot(t_plot,th_plot,'-');
xlabel('Time');  ylabel('\theta (degrees)');