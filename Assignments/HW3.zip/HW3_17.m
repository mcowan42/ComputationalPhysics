tau=input('Enter the time step: ');
maxtime=60/tau;
for i=1:179
  thetam(i)=i*pi/180; %set the value of the initial angle, in radians
  approx1(i)=2*pi; %small angle approximation
  approx2(i)=2*pi*(1+(thetam(i)).^2/16); %second approximation method
  %Verlet method for calculating r
  for n=1:maxtime
    if (n==1 || n==2)
      r(n)=thetam(i); %set first and second steps
    else
      r(n)=2*r(n-1)-r(n-2)+tau^2*(-sin(r(n-1))); %calculate subsequent steps
      if (r(n)<0) %stop calculating after 1/4 cycle
        break;
      end
    end 
  end
  per(i)=(n*tau)*4; %calculate the period of the Verlet method
end
for x=1:179
  dif_1(x)=per(x)-approx1(x); %find the difference between the approximation and the Verlet method
  if (dif_1(x)>0.1*per(x)) %stop when the difference exceeds 10%
    break;
  end
end
for y=1:179
  dif_2(y)=per(y)-approx2(y); %find the difference between the approximation and the Verlet method
  if (dif_2(y)>0.1*per(y)) %stop when the difference exceeds 10%
    break;
  end
end
thetam=thetam.*(180/pi); %convert thetam to degrees
fprintf('The first approximation reaches 10 percent error at %g degrees\n',x);
fprintf('The second approximation reaches 10 percent error at %g degrees\n',y);
plot(thetam,approx1,'-',thetam,approx2,'--',thetam,per,'o');
xlabel('Initial angle (degrees)');
ylabel('Period (s)');
title('Graph of period vs initial angle');
legend('1st approximation','2nd approximation','Verlet method','location','northwest');