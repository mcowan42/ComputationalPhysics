clear all;
L=1;  %set the needle and line spacing length
s=0;  %initialize the number of successes;
n=input('How many times should the needle be dropped? '); %number of trials
for i=1:n
  %generate values of theta and x
  theta=rand*pi;
  x=rand;
  %success condition
  if (L-x)<=L*sin(theta)
    s=s+1;
  endif
endfor
p=2*n/s;
fprintf('The calculated value of pi is: %g\n',p);