function y=root1(x,param)
  y=sqrt(1-x^2);
return;