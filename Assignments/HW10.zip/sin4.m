function y=sin4(x,param)
  y=(sin(8*x))^4;
return;