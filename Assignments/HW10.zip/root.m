function y=root(x,param)
  y=sqrt(x);
return;