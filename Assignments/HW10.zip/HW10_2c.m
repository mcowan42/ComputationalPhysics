clear all;
%set values
a=0;
b=1;
N=10;
param=0;

%calculate the Romberg table
R=rombf(a,b,N,'root',param);
%disp(R);

%calculate and display the error of the diagonals of the Romberg table
x=(1:N);
for i=1:N
  delta(i)=abs(R(i,i)-(2/3));
endfor
plot(x,delta,'+');
xlabel('nth diagonal of the Romberg table');
ylabel('Error');
title('Error in the Romberg table');