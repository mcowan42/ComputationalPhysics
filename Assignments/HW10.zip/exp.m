function y=exp(x,param)
  y=e^(x);
return;