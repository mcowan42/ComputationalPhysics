function y = uH0u(n1,n2,x)
global hbar m L;
y = ( hbar^2 / (2*m) ) * u(n1,x)*upp(n2,x);
endfunction