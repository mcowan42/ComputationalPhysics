clear all;
%set the parameters
global hbar=1 m=1 L=1;
global perturbation=0.2;
%construct the Hamiltonian matrix
for i=1:8
  for j=1:8
    M(i,j)=H0(i,j)+V(i,j);
  end
end
disp('The Hamiltonian matrix is:');
disp(M);
disp('The energy eigenvalues are:');
disp(sort(eig(M)));
disp('The basis state coefficients are:');
c=sort(eig(M-eye(8,8).*sort(eig(M))));
disp(c);
for n=1:8
  for k=0:100
    psin(n,k+1)=c(n).*u(n,k/100);
  end
end
psi=psin(1,:);
for p=2:8
  psi=psi.+psin(p,:);
end
figure(1); clf;
plot(0:0.01:1,psin);
xlabel('Position');
ylabel('Amplitude');
title('Individual States c_{n}\psi _{n}');
pause(0.5);
figure(2); clf;
plot(0:0.01:1,psi);
xlabel('Position');
ylabel('Amplitude');
title('Total Wavefunction \Psi');