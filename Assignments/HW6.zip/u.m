function y = u(n,x)
global hbar m L;
y = sqrt(2/L)*sin(n*pi*x/L);
endfunction