function y = V(i,j)
global hbar m L;
[v,ierror,nval] = quad(@(x)uVu(i,j,x),0,L);
y = v;
endfunction