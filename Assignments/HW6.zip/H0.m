function y = H0(i,j)
global hbar m L;
[v,ierror,nval] = quad(@(x)uH0u(i,j,x),0,L);
y = v;
endfunction