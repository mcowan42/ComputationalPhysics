function y = uVu(n1,n2,x)
global hbar m L;
y = u(n1,x)*vpert(x)*u(n2,x);
endfunction