function y = vpert(x)
global perturbation;
if ( x <= 0.75 ) y = 0; endif
if ( x > 0.75 ) y = perturbation; endif
endfunction