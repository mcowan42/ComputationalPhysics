function y = upp(n,x) % the second derivative of u
global hbar m L;
y = (n^2*pi^2/L^2)*sqrt(2/L)*sin(n*pi*x/L);
endfunction