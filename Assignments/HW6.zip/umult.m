function y = umult(n1,n2,x)
global hbar m L;
y = u(n1,x)*u(n2,x);
endfunction