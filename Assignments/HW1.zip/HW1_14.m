a = input('Enter the first vector: ');
b = input('Enter the second vector: ');
da=length(a); %find the number of elements in the two vectors
db=length(b);
if(da==3 && db==3) %check that both vectors are three dimensional
  maga=sqrt(a(1)^2+a(2)^2+a(3)^2);
  magb=sqrt(b(1)^2+b(2)^2+b(3)^2);
  if(maga==0 || magb==0) %check for a 0 vector
    disp('The magnitude of one or both vectors is 0');
  else
    %* Evaluate the dot product as sum over products of elements
    a_dot_b = 0;
    for i=1:3
      a_dot_b = a_dot_b + a(i)*b(i);
    end
    if( a_dot_b == 0 ) %check for orthogonality
      disp('Vectors are orthogonal');
    elseif(a(1)/b(1)==a(2)/b(2) && a(2)/b(2)==a(3)/b(3) && a(1)/b(1)==a(3)/b(3)) %check that the vectors are not parallel
      disp('Vectors are parallel so orthogonal vector can not calculated');  
    else
      u1=a/maga; %calculate the first unit vector
      v2=b-(b*u1')*u1; %calculate the second unit vector, orthogonal to the first
      magv2=sqrt(v2(1)^2+v2(2)^2+v2(3)^2);
      u2=v2/magv2;
      c=u2*magb; %result points in the direction of the second unit vector and has the same magnitude as b
      disp('Vector c is a  vector orthogonal to and in the same plane as a that has the same magnitude as b');
      %give the value of c
      disp('c=');
      disp(c);
    end
  end  
else %one or both of the vectors is not three dimensional
  disp('At least one of the vectors is not three dimensional');
end