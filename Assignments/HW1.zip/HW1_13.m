a = input('Enter the first vector: '); %input the values of the two vectors
b = input('Enter the second vector: ');
da=length(a); %find the number of elements in the two vectors
db=length(b);
if(da==3 && db==3) %first case: both vectors are three dimensional
  if(sqrt(a(1)^2+a(2)^2+a(3)^2)==0 || sqrt(b(1)^2+b(2)^2+b(3)^2)==0) %check for a 0 vector
    disp('The magnitude of one or both vectors is 0');
  else
   c1=a(2)*b(3)-a(3)*b(2); %calculate the elements of vector c
   c2=a(3)*b(1)-a(1)*b(3);
   c3=a(1)*b(2)-a(2)*b(1);
   magc=sqrt(c1^2+c2^2+c3^2); %calculate the magnitude of c
   if(magc==0) %if the vectors are parallel the cross product is 0
     disp('Vectors are parallel so orthogonal unit vector can not be calculated');
   else
     c=[c1/magc,c2/magc,c3/magc]; %construct the unit vector
     disp('Vector c is a unit vector orthogonal to both a and b'); %give the value of c
     disp('c=');
     disp(c);
   end  
  end
else %second case: one or both of the vectors are not three dimensional
  disp('At least one of the vectors is not three dimensional');
end