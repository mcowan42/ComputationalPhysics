a = input('Enter the first vector: '); %input the values of the two vectors
b = input('Enter the second vector: ');
da=length(a); %find the number of elements in the two vectors
db=length(b);
if(da==db) %first case: the vectors are the same size
  a_dot_b=a*b'; %find the dot product by multiplying a by the transpose of b
  if( a_dot_b == 0 ) %check for orthogonality
    disp('Vectors are orthogonal');
  else
    disp('Vectors are NOT orthogonal');
    fprintf('Dot product = %g \n',a_dot_b); %give the value of the dot product if a and b are not orthogonal
  end  
else %second case: the vectors are not the same size
  disp('Vectors are different sizes');
end