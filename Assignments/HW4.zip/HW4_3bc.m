% orbit - Program to compute the orbit of a comet.
clear all;  help orbit;  % Clear memory and print header
%* Set initial position and velocity of the comet.
r0 = input('Enter initial radial distance (AU): ');  
v0 = input('Enter initial tangential velocity (AU/yr): ');
r = [r0 0];  v = [0 v0];
state = [ r(1) r(2) v(1) v(2) ];   % Used by R-K routines
%* Set physical parameters (mass, G*M)
GM = 4*pi^2;      % Grav. const. * Mass of Sun (au^3/yr^2)
mass = 1;        % Mass of comet 
adaptErr = 1.e-3; % Error parameter used by adaptive Runge-Kutta
time = 0;
orb=input('Enter the number of orbits to calculate over: ');
tau = input('Enter time step (yr): ');
rev=0; 
NumericalMethod = menu('Choose a numerical method:', ...
       'Euler','Euler-Cromer','Runge-Kutta','Adaptive R-K');
iStep=0;      
while (rev<(orb*2))  
  iStep=iStep+1;
  %* Record position and energy for plotting.
  rplot(iStep) = norm(r);           % Record position for polar plot
  thplot(iStep) = atan2(r(2),r(1));
  tplot(iStep) = time;
  kinetic(iStep) = .5*mass*norm(v)^2;   % Record energies
  potential(iStep) = - GM*mass/norm(r);
  %* Calculate new position and velocity using desired method.
  if( NumericalMethod == 1 )
    accel = -GM*r/norm(r)^3;   
    r = r + tau*v;             % Euler step
    v = v + tau*accel; 
    time = time + tau;   
  elseif( NumericalMethod == 2 )
    accel = -GM*r/norm(r)^3;   
    v = v + tau*accel; 
    r = r + tau*v;             % Euler-Cromer step
    time = time + tau;     
  elseif( NumericalMethod == 3 )
    state = rk4(state,time,tau,'gravrk',GM);
    r = [state(1) state(2)];   % 4th order Runge-Kutta
    v = [state(3) state(4)];
    time = time + tau;   
  else
    [state time tau] = rka(state,time,tau,adaptErr,'gravrk',GM);
    r = [state(1) state(2)];   % Adaptive Runge-Kutta
    v = [state(3) state(4)];
  end
  %calculate the number of times the angle changes sign
  if (time>tau && thplot(iStep)*thplot(iStep-1)<0)
    rev=rev+1;
  end
  %find the period, perihelion, aphelion, semimajor axis, and eccentrity for each orbit
  if (mod(rev,2)==0 && rev>1)
    aph(rev/2)=max(rplot);
    perih(rev/2)=min(rplot);
    semimaj(rev/2)=(aph(rev/2)+perih(rev/2))/2;
    per(rev/2)=intrpf(0,[thplot(iStep),thplot(iStep-1),thplot(iStep-2)],[tplot(iStep),tplot(iStep-1),tplot(iStep-2)]);
  end
end
fprintf('The average period is %g years\n',mean(diff(per)));
fprintf('The average aphelion distance is %g AU\n',mean(aph));
fprintf('The average perihelion distance is %g AU\n',mean(perih));
fprintf('The average semimajor axis length is %g AU\n',mean(semimaj));
%* Graph the trajectory of the comet.
figure(1); clf;  % Clear figure 1 window and bring forward
polar(thplot,rplot,'+');  % Use polar plot for graphing orbit
xlabel('Distance (AU)');  grid;
pause(1)   % Pause for 1 second before drawing next plot
%* Graph the energy of the comet versus time.
figure(2); clf;   % Clear figure 2 window and bring forward
totalE = kinetic + potential;   % Total energy
plot(tplot,kinetic,'-.',tplot,potential,'--',tplot,totalE,'-')
axis([0,per(rev/2)]);
legend('Kinetic','Potential','Total');
xlabel('Time (yr)'); ylabel('Energy (M AU^2/yr^2)');
%confimation of virial theorem
disp('The average kinetic energy is:');
disp(mean(kinetic));
disp('The average potential energy divided by 2 is:');
disp(mean(potential)/2);