% orbit - Program to compute the orbit of a comet.
clear all;  help orbit;  % Clear memory and print header
%* Set physical parameters (mass, G*M)
GM = 1.15e4;      % Grav. const. * Mass of Earth (Earth radii^3/day^2)
mass = 3.7e5;        % Mass of ISS
Cd=0.8;
A=500*(6.371e6)^-2;
rho=0;
adaptErr = 1.e-6; % Error parameter used by adaptive Runge-Kutta
tau = input('Enter time step (days): ');
dif=2/(472.606*6.371e3);
%* Set initial position and velocity of the ISS
r0 = 1.0549;  
v0 = sqrt(GM/r0);
rfinal=r0;
while (r0-rfinal<dif)
  rho=rho+10^6;
  time = 0;
    r = [r0 0];  v = [0 v0];
  state = [ r(1) r(2) v(1) v(2) ];   % Used by R-K routines
  rev=0;
  iStep=0;
  while rev<2  
    iStep=iStep+1;
    %* Record position for plotting.
    rplot(iStep) = norm(r);           % Record position for polar plot
    thplot(iStep) = atan2(r(2),r(1));
    tplot(iStep) = time;
    %* Calculate new position and velocity using adaptive Runge-Kutta
    [state time tau] = rka(state,time,tau,adaptErr,'gravrk_mod',GM,Cd,A,rho,mass);
    r = [state(1) state(2)];   % Adaptive Runge-Kutta
    v = [state(3) state(4)];
    if (iStep>2 && thplot(iStep)*thplot(iStep-1)<0)
      rev=rev+1;
    end  
  end
  %interpolate to find the exact radius after one orbit
  rfinal=intrpf(0,[thplot(iStep),thplot(iStep-1),thplot(iStep-2)],[rplot(iStep),rplot(iStep-1),rplot(iStep-2)]);
end
rho=rho*(6.371e6)^-3;
fprintf('The density of the atmosphere in LEO is %g kg/m^3\n',rho);