a=[0.288833,1.00008,4.37217,18.2918,29.7024,56.4327];
T=[0.151265,0.998648,8.23633,72.734,144.514,375.452];
loglog(a.^3,T.^2,'+',[10^-2,10^6],[10^-2,10^6],'--');
xlabel('Semimajor axis length (AU) cubed');
ylabel('Period (yr) squared');
title('Period vs semimajor axis length');