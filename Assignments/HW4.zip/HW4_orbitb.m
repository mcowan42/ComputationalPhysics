% orbit - Program to compute the orbit of a comet.
clear all;  help orbit;  % Clear memory and print header
%* Set physical parameters (mass, G*M)
GM = 1.15e4;      % Grav. const. * Mass of Earth (Earth radii^3/day^2)
mass = 3.7e5;        % Mass of ISS 
adaptErr = 1.e-6; % Error parameter used by adaptive Runge-Kutta
time = 0;
%* Set initial position and velocity of the comet.
r0 = 1.0549;  
v0 = sqrt(GM/r0);
r = [r0 0];  v = [0 v0];
state = [ r(1) r(2) v(1) v(2) ];   % Used by R-K routines
maxtime = input('Enter length of time to orbit (days): ');
tau = input('Enter time step (days): '); 
rev=0;
iStep=0;
while time<maxtime  
  iStep=iStep+1;
  %* Record position for plotting.
  rplot(iStep) = norm(r);           % Record position for polar plot
  thplot(iStep) = atan2(r(2),r(1));
  tplot(iStep) = time;
  %* Calculate new position and velocity using adaptive Runge-Kutta
  [state time tau] = rka(state,time,tau,adaptErr,'gravrk',GM);
  r = [state(1) state(2)];   % Adaptive Runge-Kutta
  v = [state(3) state(4)];
  if (iStep>2 && thplot(iStep)*thplot(iStep-1)<0)
    rev=rev+1;
  end  
end
%interpolate to find the exact angle at the specified end time
thfinal=intrpf(maxtime,[tplot(iStep),tplot(iStep-1),tplot(iStep-2)],[thplot(iStep),thplot(iStep-1),thplot(iStep-2)]);
%Count the number of orbits by halving the number of reversals and adding in the fraction of the current orbit
if (thplot(iStep)>0)
  orb=floor(rev/2)+thfinal/(2*pi);
else
  orb=floor(rev/2)+thfinal/(2*pi)+1;
end
fprintf('The ISS makes %g orbits in %g days\n',orb,maxtime);
%* Graph the trajectory of the comet.
figure(1); clf;  % Clear figure 1 window and bring forward
polar(thplot,rplot,'+');  % Use polar plot for graphing orbit
xlabel('Distance (Earth radii)');  grid;