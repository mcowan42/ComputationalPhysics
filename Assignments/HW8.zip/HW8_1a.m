clear all;
global n=input('How many images to calculate?');
global t=input('At what time (s) would you like to see the temperature distribution?');
global kappa=1;
global L=1;

function y=sigma(t)
  global kappa
  y=sqrt(2*kappa*t);
endfunction

function y=Tg(i,x,t)
  y=(sigma(t)*sqrt(2*pi))^(-1)*exp(-(x)^2/(2*(sigma(t))^2));
endfunction

%Define the range over which to graph
x=(1:151)*(3*L/150)-3*L/2-(3*L/150);
for i=1:n
  for j=1:151
    T0(j)=Tg(0,x(j),t); %the distribution in the bar
    T(j)=(-1)^i*Tg(i,x(j)+i*L,t)+(-1)^-i*Tg(-i,x(j)-i*L,t); %add the distributions in the images
    Ttot=T0+T;
  end
  %plot the bar and the images separately
  figure(1);
  plot(x,T0,'-',x,T,'-.');
  xlabel('x/L');
  ylabel('T(x,t)');
end
%plot the bar and the images together
figure(2); clf;
plot(x,Ttot);
xlabel('x/L');
ylabel('T(x,t)');