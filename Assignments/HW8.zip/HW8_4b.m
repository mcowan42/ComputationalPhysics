% diffusion equation solution using
% spectral method.
%
% E.H. Majzoub for CompPhys 4350
% UM-St. Louis
% 16 Nov 2010
% Modified by M. Cowan 27 Apr 2015
clear;
warning("off","all");

t0=0; t1=0.001; t2=0.003; t3=0.01; t4=0.03; t5=0.1;
global maxorder=10;
maxplot=60;

% let the length L=1
global L=1;
global k=1;
global A;
global B;
global S;
global h=L/maxplot;
% B.C.s: T=0 at x= +/- L/2

# Frist, we define the basis set
#
function y = omega1(n)
  global L;
  n=n-1;
  y = (2*n+1)*pi/(L);
endfunction

function y = omega2(n)
  global L;
  n=n-1;
  y = (2*n)*pi/(L);
endfunction


function y = u1(n,x)
  global L;
  y = (2/L) * cos( omega1(n) * x );
endfunction

function y = u2(n,x)
  global L;
  y = (2/L) * sin( omega2(n) * x );
endfunction


# Define zero time distribution
function y = fzero(x)
  global L;
  if (x>=0 && x<=L/4)
    y=4/L;
  else
    y=0;
  end
endfunction

function y = source(x)
  global h;
  y=0;
  if (abs(x)<=h/4)
    y=1/h;
  end
endfunction

# Define some functions for integration
function y = ufmult1(n1,x)
  y = u1(n1,x)*fzero(x);
endfunction

function y = ufmult2(n1,x)
  y = u2(n1,x)*fzero(x);
endfunction

function y = ufmult3(n1,x)
  global L;
  y = (2/L)*u1(n1,x)*source(x);
endfunction

# calculate the coeffs
function y = coef1(n)
  global L;
  [v,ierror,nval] = quad( @(x) ufmult1(n,x),-L/2,L/2);
  y = v;
endfunction

function y = coef2(n)
  global L;
  [v,ierror,nval] = quad( @(x) ufmult2(n,x),-L/2,L/2);
  y = v;
endfunction

function y = coef3(n)
  global L;
  [v,ierror,nval] = quad( @(x) ufmult3(n,x),-L/2,L/2);
  y = v;
endfunction

# calculate the temperature distribution
function y = T(x,t)
  global k L A B maxorder;
  y=0;
  for n=1:maxorder
    y = y + A(n)*exp(-k*omega1(n)**2*t)*cos(omega1(n)*x) + B(n)*exp(-k*omega2(n)**2*t)*sin(omega2(n)*x);
  endfor
endfunction

# calculate the source
function y = Ts(x)
  global k S maxorder;
  y=0;
  for(n=1:maxorder)
    y=y+S(n)*exp(-k*omega1(n)^2*.05)*u1(n,x);
  endfor
endfunction

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calculate the coefs first
for i=1:maxorder
  A(i) = coef1(i);
  B(i) = coef2(i);
  S(i) = coef3(i);
endfor

x = -L/2-(L/maxplot) + (1:maxplot+1)*(L/maxplot);

for(j=1:50)
  time(j)=j/50;
  for(i=1:maxplot+1)
    yT(i,j)=T(x(i),time(j));
    yTs(i,j)=Ts(x(i));
  endfor
endfor

yTot=yT.+yTs;

figure(1);  clf;
mesh(time,x,yT);
xlabel('Time');  ylabel('x');  zlabel('T(x,t)');
title('Temperature distribution without heat source');

figure(2);  clf;
mesh(time,x,yTot);
xlabel('Time');  ylabel('x');  zlabel('T(x,t)');
title('Temperature distribution with heat source');