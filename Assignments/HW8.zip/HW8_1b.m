% dftcs - Program to solve the diffusion equation 
% using the Forward Time Centered Space (FTCS) scheme.
clear; help dftcs;  % Clear memory and print header

%* Initialize parameters (time step, grid spacing, etc.).
global tau = input('Enter time step: ');
global N = input('Enter the number of grid points: ');
global L = 1.;  % The system extends from x=-L/2 to x=L/2
global h = L/(N-1);  % Grid size
global kappa = 1.;   % Diffusion coefficient
image=10; %number of images to calculate
coeff = kappa*tau/h^2;
if( coeff < 0.5 )
  disp('Solution is expected to be stable');
else
  disp('WARNING: Solution is expected to be unstable');
end

%* Set initial and boundary conditions.
tt = zeros(N,1);          % Initialize temperature to zero at all points
tt(round(N/2)) = 1/h;     % Initial cond. is delta function in center
%% The boundary conditions are tt(1) = tt(N) = 0

%* Set up loop and plot variables.
xplot = (0:N-1)*h - L/2;   % Record the x scale for plots
iplot = 1;                 % Counter used to count plots
nstep = 300;               % Maximum number of iterations
nplots = 50;               % Number of snapshots (plots) to take
plot_step = nstep/nplots;  % Number of time steps between plots

%* Loop over the desired number of time steps.
for istep=1:nstep  %% MAIN LOOP %%

  %* Compute new temperature using FTCS scheme.
  tt(2:(N-1)) = tt(2:(N-1)) + ...
      coeff*(tt(3:N) + tt(1:(N-2)) - 2*tt(2:(N-1)));
  
  %* Periodically record temperature for plotting.
  if( rem(istep,plot_step) < 1 )   % Every plot_step steps
    ttplot(:,iplot) = tt(:);       % record tt(i) for plotting
    tplot(iplot) = istep*tau;      % Record time for plots
    iplot = iplot+1;
  end
end

function y=sigma(t)
  global kappa
  y=sqrt(2*kappa*t);
endfunction

function y=Tg(i,x,t)
  y=(sigma(t)*sqrt(2*pi))^(-1)*exp(-(x)^2/(2*(sigma(t))^2));
endfunction

x=xplot; %create grid for Ta
for k=1:nplots
  for i=1:image
    for j=1:N
      t=k*tau;
      T0(j,k)=Tg(0,x(j),t); %the distribution in the bar
      T(j,k)=(-1)^i*Tg(i,x(j)+i*L,t)+(-1)^-i*Tg(-i,x(j)-i*L,t); %add the distributions in the images
      Ttot=T0+T;
    end
  end
end

deltat=abs(Ttot-ttplot);

%* Plot temperature versus x and t as wire-mesh and contour plots.
figure(1); clf;
mesh(tplot,xplot,ttplot);  % Wire-mesh surface plot
xlabel('Time');  ylabel('x');  zlabel('T(x,t)');
title('Diffusion of a delta spike');
pause(0.5);
figure(2); clf;       
contourLevels = 0:0.5:10;  contourLabels = 0:5;     
cs = contour(tplot,xplot,ttplot,contourLevels);  % Contour plot
clabel(cs,contourLabels);  % Add labels to selected contour levels
xlabel('Time'); ylabel('x');
title('Temperature contour plot');
pause(0.5);
figure(3);clf;
mesh(tplot,xplot,deltat);
xlabel('Time');  ylabel('x');  zlabel('|Ta(x,t)-Tc(x,t)|');
title('Comparison of the diffusion of a delta spike using FTCS and image methods');
pause(0.5);
figure(4);clf;
mesh(tplot,xplot,Ttot);
xlabel('Time');  ylabel('x');  zlabel('T(x,t)');
title('Diffusion of a delta spike using image method');