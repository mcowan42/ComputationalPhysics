% diffusion equation solution using
% spectral method.
%
% E.H. Majzoub for CompPhys 4350
% UM-St. Louis
% 16 Nov 2010
% Modified by M. Cowan 27 Apr 2015
clear;
warning("off","all");

t0=0; t1=0.001; t2=0.003; t3=0.01; t4=0.03; t5=0.1;
global maxorder=10;
maxplot=60;

% let the length L=1
global L=1;
global k=1;
global A;
global B;
% B.C.s: T=0 at x= +/- L/2

# Frist, we define the basis set
#
function y = omega1(n)
  global L;
  n=n-1;
  y = (2*n+1)*pi/(L);
endfunction

function y = omega2(n)
  global L;
  n=n-1;
  y = (2*n)*pi/(L);
endfunction


function y = u1(n,x)
  global L;
  y = (2/L) * cos( omega1(n) * x );
endfunction

function y = u2(n,x)
  global L;
  y = (2/L) * sin( omega2(n) * x );
endfunction


# Define zero time distribution
function y = fzero(x)
  global L;
  if (x>=0 && x<=L/4)
    y=4/L;
  else
    y=0;
  end
endfunction

# Define some functions for integration
function y = ufmult1(n1,x)
  y = u1(n1,x)*fzero(x);
endfunction

function y = ufmult2(n1,x)
  y = u2(n1,x)*fzero(x);
endfunction


# calculate the coeffs
function y = coef1(n)
  global L;
  [v,ierror,nval] = quad( @(x) ufmult1(n,x),-L/2,L/2);
  y = v;
endfunction

function y = coef2(n)
  global L;
  [v,ierror,nval] = quad( @(x) ufmult2(n,x),-L/2,L/2);
  y = v;
endfunction


# calculate the temperature distribution
function y = T(x,t)
  global k L A B maxorder;
  y=0;
  for n=1:maxorder
    y = y + A(n)*exp(-k*omega1(n)**2*t)*cos(omega1(n)*x) + B(n)*exp(-k*omega2(n)**2*t)*sin(omega2(n)*x);
  endfor
endfunction


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% calculate the coefs first
for i=1:maxorder
  A(i) = coef1(i);
  B(i) = coef2(i);
endfor

x = -L/2-(L/maxplot) + (1:maxplot+1)*(L/maxplot);
for i=1:maxplot+1
  yfzero(i) = fzero(x(i));
  yT0(i) = T(x(i),t0);
  yT1(i) = T(x(i),t1);
  yT2(i) = T(x(i),t2);
  yT3(i) = T(x(i),t3);
  yT4(i) = T(x(i),t4);
  yT5(i) = T(x(i),t5);
endfor



figure(1); clf;
plot(x,yfzero,'-',x,yT1,'-',x,yT2,'-',x,yT3,'-',x,yT4,'-',x,yT5,'-');
legend("t0","t1","t2","t3","t4","t5");
xlabel("Position [L]");
ylabel("Temperature (norm)");
refresh(1);
print("diffout.png");