clear all;
n=input('Enter the number of data points to be fit: ');
%enter the data points
for i=1:n
  A=input('Enter a data point [xi,yi]: ');
  x(i)=A(1);
  y(i)=A(2);
end
%calculate the matrix elements
gamma=sum(x.^2);
delta=sum(x);
beta=sum(x.*y);
ksi=sum(y);
M=[gamma,delta;delta,n];
c=[beta;ksi];
r=M^-1*c; %calculate the slope and y-intercept
disp('The slope of the least square linear fit is:');
disp(r(1));
disp('The y-intercept of the least square linear fit is:');
disp(r(2));
%construct the linear fit from the endpoints
xg=[0,x(n)];
yg=[r(2),r(1)*x(n)+r(2)];
%plot the data points and the linear fit
figure(1); clf;
plot(x,y,'o',xg,yg,'--');
xlabel('x');
ylabel('y');
title('Data points (x,y) with least square linear fit');