clear all;
%set parameters
hbar=1;
m=1;
omega=1;
L=input('Input the width over which to calculate: ');
N=input('Input the number of steps: ');
a=L/N;
alpha=hbar^2/(2*m*a^2);
x=(-L/2):a:(L/2);
%construct the Hamiltonian matrix
for i=1:N+1
  for j=1:N+1
    if i==j
      V(j)=0.5*m*omega^2*x(j)^2;
      H(i,j)=2*alpha+V(j);
    elseif ((j==i-1 && i-1~=0) || (j==i+1 && i+1~=N+2))
      H(i,j)=-alpha;
    else
      H(i,j)=0;
    end  
  end
end  
[psi,E]=eig(H); %find the eigenvectors and eigenvalues
fprintf('The energy of the ground state is %g \n',E(1,1));
fprintf('The energy of the first excited state is %g \n',E(2,2));
figure(1); clf;
plot(x,psi(:,1));
xlabel('Position');
ylabel('\Psi');
title('Ground state wave function of the QSHO potential');
figure(2); clf;
plot(x,psi(:,2));
xlabel('Position');
ylabel('\Psi');
title('First excited state wave function of the QSHO potential');