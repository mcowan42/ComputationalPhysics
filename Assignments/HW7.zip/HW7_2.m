clear all;
%import the data from a text file
ma=dlmread('Mauna.txt');
ba=dlmread('Barrow.txt');
%transpose the data into a row matrix
ma=ma';
ba=ba';
%find the number of data points
n1=size(ma,2);
n2=size(ba,2);
%create a vector with the dates
x1 = [0:14/365:229*14/365] +1981;
x2 = [0:14/365:229*14/365] +1981;
%calculate the matrix elements
gamma1=sum(x1.^2);
delta1=sum(x1);
beta1=sum(x1.*ma);
ksi1=sum(ma);
gamma2=sum(x2.^2);
delta2=sum(x2);
beta2=sum(x2.*ba);
ksi2=sum(ba);
M1=[gamma1,delta1;delta1,n1];
M2=[gamma2,delta2;delta2,n2];
c1=[beta1;ksi1];
c2=[beta2;ksi2];
r1=M1^-1*c1; %calculate the slope and y-intercept
r2=M2^-1*c2; %calculate the slope and y-intercept
disp('The annual rate of increase of CO2 in ppm at Mauna Loa is:');
disp(r1(1));
disp('The annual rate of increase of CO2 in ppm at Barrow, AK is:');
disp(r2(1));
%calculate the linear fit
xg1=[x1(1),x1(n1)];
yg1=[r1(1)*x1(1)+r1(2),r1(1)*x1(n1)+r1(2)];
figure(1); clf;
plot(x1,ma,'+',xg1,yg1,'--');
xlabel('Year');
ylabel('CO2 (ppm)');
title('Carbon Dioxide concentration at Mauna Loa');
%calculate the linear fit
xg2=[x2(1),x2(n2)];
yg2=[r2(1)*x2(1)+r2(2),r2(1)*x2(n2)+r2(2)];
figure(2); clf;
plot(x2,ba,'+',xg2,yg2,'--');
xlabel('Year');
ylabel('CO2 (ppm)');
title('Carbon Dioxide concentration at Barrow,AK');
%calculating when the CO2 concentration increases by 10 percent from the 1981 level
y1=max(ma(1:26))*1.1;
y2=max(ba(1:26))*1.1;
x1_10=(y1-r1(2))/r1(1);
x2_10=(y2-r2(2))/r2(1);
fprintf('The CO2 level at Mauna Loa will be 10 percent above its 1981 value in %g \n',floor(x1_10));
fprintf('The CO2 level at Barrow,AK will be 10 percent above its 1981 value in %g \n',floor(x2_10));