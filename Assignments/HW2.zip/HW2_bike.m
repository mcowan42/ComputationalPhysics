m=input('Mass of the cyclist (kg): '); %Define and input all of the variables
P=input('Power output of the cyclist (W): ');
A=input('Cross sectional area (m^2): ');
r=input('Density of air (kg/m^3): ');
v(1)=input('Initial speed (m/s): ');
inc=input('Time increment (s): ');
vno(1)=v(1); %vno is the velocity without drag
t(1)=0;
n=600/inc; %calculates the number of increments in 10 minutes
for i=1:n %loops the calculation of v
  v(i+1)=v(i)+((inc*P)/(m*v(i)))-((inc*0.25*r*A*v(i)^2)/m); %calculate the new value of v
  vno(i+1)=vno(i)+((inc*P)/(m*vno(i))); %calculate the new value of vno
  t(i+1)=t(i)+inc; %creates a matrix of time values for plotting
  if (abs(v(i+1)-v(i))<0.0001)
    break %break the loop if v is no longer increasing
  end
end
fprintf('The terminal velocity of the cyclist is %g m/s \n',v(i+1));
plot(t,v,'-',t,vno,'--');
xlabel('Time (s)');
ylabel('Velocity (m/s)');
title('Graph of velocity vs. time');
legend('Velocity with drag','Velocity without drag');