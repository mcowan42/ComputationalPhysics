clear all;
n=0:20;
h=10.^(-n); %set the values of h
for i=1:21
  dera(i)=(((1+h(i))^2)-1^2)/h(i); %derivative for a
  deltaa(i)=abs(2*(1)-(dera(i))); %delta for a
  derb(i)=(((1+h(i))^5)-1^5)/h(i); %derivative for b
  deltab(i)=abs(5*(1)^4-(derb(i))); %delta for b
  derc(i)=((sin(0+h(i)))-sin(0))/h(i); %derivative for c
  deltac(i)=abs(cos(0)-(derc(i))); %delta for c
  derd(i)=((sin(pi/4+h(i)))-sin(pi/4))/h(i); %derivative for d
  deltad(i)=abs(cos(pi/4)-(derd(i))); %delta for d
  dere(i)=((sin(pi/2+h(i)))-sin(pi/2))/h(i); %derivative for e
  deltae(i)=abs(cos(pi/2)-(dere(i))); %delta for e
end
subplot(3,3,1);
loglog(h,deltaa,'+');
xlabel('h');
ylabel('delta(h)');
title('Error delta as a function of h for y=x^2 at x=1');
subplot(3,3,3);
loglog(h,deltab,'+')
xlabel('h');
ylabel('delta(h)')
title('Error delta as a function of h for y=x^5 at x=1');
subplot(3,3,5);
loglog(h,deltac,'+')
xlabel('h');
ylabel('delta(h)')
title('Error delta as a function of h for y=sin(x) at x=0');
subplot(3,3,7);
loglog(h,deltad,'+')
xlabel('h');
ylabel('delta(h)')
title('Error delta as a function of h for y=sin(x) at x=pi/4');
subplot(3,3,9);
loglog(h,deltae,'+')
xlabel('h');
ylabel('delta(h)')
title('Error delta as a function of h for y=sin(x) at x=pi/2');