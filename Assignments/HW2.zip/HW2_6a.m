clear;

%* Set initial position and velocity of the baseball
m1=input('Enter the mass of the larger sphere (lb): ');
m2=input('Enter the mass of the smaller sphere (lb): ');
h = input('Enter initial height (meters): '); % Initial height
r1 = h; %Set initial position for both masses
r2 = h;
v1 = 0;  % Set initial velocity for both masses
v2 = 0;

m1=m1/2.20462; %convert lb to kg
m2=m2/2.20462;

%* Set physical parameters (mass, Cd, etc.)
Cd = 0.5;      % Drag coefficient (dimensionless)
area1 = pi*((3/(4*pi))*m1*(1000/7.8)*10^-6)^(2/3);  % Cross-sectional area of projectile (m^2)...
%computed using the mass and density, plus several conversion factors
area2 = pi*((3/(4*pi))*m2*(1000/7.8)*10^-6)^(2/3);
grav = 9.81;    % Gravitational acceleration (m/s^2)
airFlag = input('Air resistance? (Yes:1, No:0): ');
if( airFlag == 0 )
  rho = 0;      % No air resistance
else
  rho = 1.2;    % Density of air (kg/m^3)
end
air_const1 = -0.5*Cd*rho*area1/m1;  % Air resistance constant
air_const2 = -0.5*Cd*rho*area2/m2;  % for each mass

%* Loop until ball hits ground or max steps completed
tau = input('Enter timestep, tau (sec): ');  % (sec)
maxstep = 1000;   % Maximum number of steps
for istep=1:maxstep

  %* Record position (computed and theoretical) for plotting
  yplot1(istep) = r1;   % Record trajectory for plot
  yplot2(istep) = r2;
  t(istep) = (istep-1)*tau;     % Current time
  
  %* Calculate the acceleration of the ball 
  accel1 = air_const1*norm(v1)*v1-grav;   % for mass 1
  accel2 = air_const2*norm(v2)*v2-grav;   % for mass 2
  
  %* Calculate the new position and velocity using Euler method
  r1 = r1 + tau*v1;                 % Euler step
  v1 = v1 + tau*accel1;
  r2 = r2 + tau*v2;                 % Euler step
  v2 = v2 + tau*accel2;
  
  %* If ball reaches ground (y<0), break out of the loop
  if(r1 < 0 )  
    y=[(istep-2)*tau,(istep-1)*tau,istep*tau]; %to use intrpf as written to find the time where y=0 for mass 1
    x=[yplot1(istep-1),yplot1(istep),r1]; %need to switch the x and y data, use the current and two previous points
    xi = 0;
    t(istep+1) = intrpf(xi,x,y);  % Use intrpf function to interpolate to find the final time
	  yplot1(istep+1) = 0;
    y=[yplot2(istep-1),yplot2(istep),r2]; %using the final three time values
    yplot2(istep+1)=intrpf(xi,x,y); %use intrpf function to interpolate to find height of the smaller mass...
    %when the larger mass hits the ground
    break;                  % Break out of the for loop
  end 
end

%* Print time of flight and height of lighter mass
fprintf('It takes %g seconds for the larger mass to hit the ground\n',t(istep+1));
fprintf('The height of the smaller mass at that time is %g meters\n',yplot2(istep+1));

%* Graph the trajectory of the baseball
clf;  figure(gcf);   % Clear figure window and bring it forward
% Plot the heights of the two masses
plot(t,yplot1,'+',t,yplot2,'o');
legend('mass 1','mass 2');
xlabel('Time (s)');  ylabel('Height (m)');
title('Falling with air resistance');