clear all;
theta0=input('Input the initial angle (degrees): ');
tau=input('Input the time step (s): ');
maxstep=input('Input the number of steps: ');
theta=theta0*pi/180;
omega=0;
time=0;
g_over_L=1;
qd=.5;
fd=2/3;
Ad=1.2;
j=0;
for i=1:maxstep
  theta_bound = theta*180/pi+180;
  theta_bound = mod(theta_bound,360) - 180;
  %to save space, only plot every 50th point
  if (mod(i,50)==0)
    thplot(i/50)=theta_bound;
    omegaplot(i/50)=omega*180/pi;
  end
  accel = -g_over_L*sin(theta) - qd *omega + Ad*sin(fd * time);
  omega = omega + tau*accel;
  theta = theta + tau*omega;
  time=time+tau;
  %create the Poincare section (plot omega vs theta once per period)
  if ( mod( fd*time-pi/4 , 2*pi ) < tau/2 )
    j=j+1;
    thpoin(j)=theta_bound;
    omegapoin(j)=omega*180/pi;
  end
end
figure(1); clf;
plot(thplot,omegaplot,'.');
xlabel('theta (degrees)');
ylabel('omega (degress/second)');
title('Phase Space');
pause(0.5);
figure(2); clf;
plot(thpoin,omegapoin,'.');
xlabel('theta (degrees)');
ylabel('omega (degress/second)');
title('Poincare Section');