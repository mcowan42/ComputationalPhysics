clear all;
disp('Input the matrix to be inverted in the form [a11,a12,a13,...;a21,a22,a23,...;a31,a32,a33...;...ann]:');
A=input('');
[m,n]=size(A);
if (m~=n) %check that the matrix is a square matrix
  disp('The matrix is not a square matrix so it has no inverse.');
else
  B=[A,eye(n,n)]; %create the augmented matrix by appending an identity matrix to A
  %check to see if any of the main diagonal elements <<1
  for i=1:n
    if abs(B(i,i))<1e-4
      %if the element is equal to 0, pivot the matrix
      if abs(B(i,i))==0
        if i==n
          circshift(B,1);
          i=1;
        else
          for j=i+1:n
            if B(j,i)~=0
              temp=B(j,:);
              B(j,:)=B(i,:);
              B(i,:)=temp;
            end
          end
        end  
      else %if the element is small but not 0, multiply the row by its reciprocal
        B(i,:)=(1/B(i,i)).*B(i,:);  
      end
    end
  end  
  %Gaussian elimination
  for i=1:n
    B(i,:)=B(i,:)./B(i,i);
    for j=1:n
      if (j~=i) %skip the row we're working on
        B(j,:)=B(j,:).-(B(j,i).*B(i,:)); %change the rest of the column to 0's
      end
    end
  end
  %retreive the right half of the augmented matrix
  for i=1:n
    for j=1:n
      C(i,j)=B(i,j+n);
    end
  end
  disp('The inverse is: ');
  disp(C);
end