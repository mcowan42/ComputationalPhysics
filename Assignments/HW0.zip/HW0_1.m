A=[1 2;3 4]; %Assign values to matrix A
disp('(a) A*A=');
disp(A*A); %Multiply A by itself
disp('(b) A.*A=');
disp(A.*A); %Multiply each element in A by itself
disp('(c) A^2=');
disp(A^2); %A^2 gives the same result as A*A
disp('(d) A.^2=');
disp(A.^2); %A.^2 gives the same result as A.*A
disp('(e) A/A=');
disp(A/A); %Dividing a matrix by itself gives an identity matrix
disp('(f) A./A=');
disp(A./A); %Dividing each matrix element by itself gives a matrix of 1's