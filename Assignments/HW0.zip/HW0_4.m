A=[1 2 3;0 4 5;0 0 6]; %assign value to matrix A
disp('A=');
disp (A); %print A
disp('inv(A)=');
disp(inv(A)); %print inverse of A
disp('A*inv(A)=');
disp(A*inv(A)); %check that A multiplied by its inverse produces the identity matrix
B=[1 0 0;0 2 0;0 0 3]; %assign value to matrix B
disp('B=');
disp (B); %print B
disp('inv(B)=');
disp(inv(B)); %print inverse of B
disp('B*inv(B)=');
disp(B*inv(B)); %check that B multiplied by its inverse produces the identity matrix
C=[1 2 3;4 5 6;7 8 9]; %assign value to matrix C
disp('C=');
disp (C); %print C
disp('inv(C)=');
disp(inv(C)); %print inverse of C
disp('C*inv(C)=');
disp(C*inv(C)); %check that C multiplied by its inverse produces the identity matrix
D=[1 1/2 1/3;1/4 1/5 1/6;1/7 1/8 1/9]; %assign value to matrix D
disp('D=');
disp (D); %print D
disp('inv(D)=');
disp(inv(D)); %print inverse of D
disp('D*inv(D)=');
disp(D*inv(D)); %check that D multiplied by its inverse produces the identity matrix
disp('eig(A)=');
disp(eig(A)); %print the eigenvalues of A
disp('eig(B)=');
disp(eig(B)); %print the eigenvalues of B
disp('eig(C)=');
disp(eig(C)); %print the eigenvalues of C
disp('eig(D)=');
disp(eig(D)); %print the eigenvalues of D