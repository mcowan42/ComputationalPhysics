x=0:pi/64:6*pi;
y=(sin(3*x)).^2;
polar(x,y)