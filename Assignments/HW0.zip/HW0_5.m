A=[1 2 3;0 4 5;0 0 6];
B=[1 0 0;0 2 0;0 0 3];
C=[1 2 3;4 5 6;7 8 9];
D=[1 1/2 1/3;1/4 1/5 1/6;1/7 1/8 1/9];
w=0;  %assign each output function an initial value of 0
x=0;
y=0;
z=0;
for n=0:5 %iterates the loop 6 times, with n incrementing by 1 each iteration
  w=w+(A^n)/factorial(n); %each iteration is added to the total from the previous iteration
  x=x+(B^n)/factorial(n);
  y=y+(C^n)/factorial(n);
  z=z+(D^n)/factorial(n);
end
disp('e^A=');
disp(w); %approximate value of e^A
disp('expm(A)=');
disp(expm(A)); %exact value of e^A
disp('e^B=');
disp(x); %approximate value of e^B
disp('expm(B)=');
disp(expm(B)); %exact value of e^B
disp('e^C=');
disp(y); %approximate value of e^C
disp('expm(C)=');
disp(expm(C)); %exact value of e^C
disp('e^D=');
disp(z); %approximate value of e^D
disp('expm(D)=');
disp(expm(D)); %exact value of e^D