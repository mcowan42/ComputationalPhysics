x=0:pi/32:6*pi;
y=exp(-x/4).*sin(x);
plot(x,y);
title('f(x)=exp(-x/4)*sin(x)');
xlabel('x');
ylabel('f(x)')