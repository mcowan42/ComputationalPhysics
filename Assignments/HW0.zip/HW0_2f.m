x=1:10;
y=x.^2;
loglog(x,y,'+')