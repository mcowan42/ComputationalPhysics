x=0:pi/32:6*pi;
y=exp(-x/4).*sin(x);
z=exp(-x/4);
plot(x,y,'-',x,z,'--',x(1:16:193),y(1:16:193),'o');
title('f(x)=exp(-x/4)*sin(x)');
xlabel('x');
ylabel('f(x)');