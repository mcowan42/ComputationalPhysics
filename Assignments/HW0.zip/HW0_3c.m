x=0:.2:6*pi;
y=exp(-x).*(sin(x)).^2;
semilogy(x,y,'+');
axis([0,6*pi,10^-10,10^0]); %sets the ranges of the axes
title('f(x)=exp(-x)*sin(x)');
xlabel('x');
ylabel('f(x)');